

export const config = {
  host: "localhost",
  port: 3306,
  user: "root",
  password: 'qazwsx123',
  database: "L6",
  connection_limit: 100
}

// https://www.postgresql.org/download/windows/
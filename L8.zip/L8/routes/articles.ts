import Router, {RouterContext} from "koa-router";
import bodyParser from "koa-bodyparser";
import * as model from "../models/articles";
import { validateArticle } from "../controllers/validation";




const router = new Router({prefix: '/api/v1/articles'});

/**
 * @openapi
 * /articles:
 *   get:
 *     summary: Get all articles
 *     description: Retrieve a list of all articles from the database
 *     responses:
 *       200:
 *         description: A list of articles
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Article'
 */
const getAll = async (ctx: RouterContext, next: any) => {
  
  let articles = await model.getAll();
  if(articles.length) {
    ctx.body = articles;
  } else {
    ctx.body = {};
  }
  await next();
}

/**
 * @openapi
 * /articles:
 *   post:
 *     summary: Create a new article
 *     description: Create a new article with the provided data
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Article'
 *     responses:
 *       201:
 *         description: Article created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Article'
 *       400:
 *         description: Validation error
 *       500:
 *         description: Insert data failed
 */
const createArticle = async (ctx: RouterContext, next: any) => {
  
  const body = ctx.request.body;
  let result = await model.add(body);
  if(result.status==201) {
    ctx.status = 201;
    ctx.body = body;
  } else {
    ctx.status = 500;
    ctx.body = {err: "insert data failed"};
  }
  await next();
}

/**
 * @openapi
 * /articles/{id}:
 *   get:
 *     summary: Get article by ID
 *     description: Retrieve a specific article by its ID
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: The article ID
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Article details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Article'
 *       404:
 *         description: Article not found
 */
const getById = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;
  
  let article = await model.getById(id);
  if(article.length) {
    ctx.body = article[0];
  } else {
    ctx.status = 404;
  }
  await next();
}

/**
 * @openapi
 * /articles/{id}:
 *   put:
 *     summary: Update an article
 *     description: Update an existing article with new data
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: The article ID
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Article'
 *     responses:
 *       201:
 *         description: Article updated successfully
 *       400:
 *         description: Validation error
 */
const updateArticle = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;
  //let {title, fullText} = ctx.request.body;
  let c: any = ctx.request.body;
  
  let result = await model.update(c,id)
  if (result) {
    ctx.status = 201
    ctx.body = `Article with id ${id} updated` 
  } 
  await next();
}

/**
 * @openapi
 * /articles/{id}:
 *   delete:
 *     summary: Delete an article
 *     description: Delete an article by its ID
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: The article ID
 *         schema:
 *           type: integer
 *     responses:
 *       201:
 *         description: Article deleted successfully
 */
const deleteArticle = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;
 
let article = await model.deleteById(id)
  ctx.status=201
    ctx.body = `Article with id ${id} deleted`
  await next();
}

router.get('/', getAll);
router.post('/',  bodyParser(), validateArticle, createArticle);
router.get('/:id([0-9]{1,})', getById);
router.put('/:id([0-9]{1,})',  bodyParser(), validateArticle, updateArticle);
router.delete('/:id([0-9]{1,})',  deleteArticle);

export { router };

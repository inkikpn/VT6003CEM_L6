import Koa from "koa";
import Router, { RouterContext } from "koa-router";
import logger from "koa-logger";
import json from "koa-json";
import { router as articles } from "./routes/articles";
import { router as special } from "./routes/special";
import serve from "koa-static";
import mount from "koa-mount";
import { koaSwagger } from "koa2-swagger-ui";
import yamljs from "yamljs";
import path from "path";

  
const app: Koa = new Koa();
const router: Router = new Router();


const spec = yamljs.load(path.join(__dirname, '../docs/openapi.yaml'));


app.use(serve(path.join(__dirname, '../docs')));


app.use(
  koaSwagger({
    routePrefix: '/docs',
    swaggerOptions: {
      spec,
    },
    hideTopbar: false,
  })
);


router.get('/api-docs', (ctx) => {
  ctx.body = spec;
});


router.get('/redoc', (ctx) => {
  ctx.redirect('/redoc.html');
});

/*const welcomeAPI = async (ctx: RouterContext, next:any) => {
  ctx.body = {message: "Welcome to the blog API!"};
  await next();
}

router.get('/api/v1', welcomeAPI);*/
// For Document:

app.use(logger());
app.use(json());
app.use(router.routes());
app.use(articles.middleware());
app.use(special.middleware());




app.use(async (ctx: RouterContext, next: any) => {
  try {
    await next();
    console.log(ctx.status)
    if(ctx.status === 404){
      ctx.body = {err: "Resource not found"};
    }
  } catch(err: any) {
    ctx.body = {err: err};
  }
  
});

app.listen(5000, () => {
  console.log("Koa Started on http://localhost:5000");
  console.log("API Documentation (Swagger UI) available at http://localhost:5000/docs");
  console.log("API Documentation (ReDoc) available at http://localhost:5000/redoc");
  console.log("OpenAPI Specification available at http://localhost:5000/api-docs");
});